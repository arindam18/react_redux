import React, { Component } from 'react';
import logo from '../styles/logo.svg';
import '../styles/App.css';
import Landing from './landing.js';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Landing />
      </div>
    );
  }
}

export default App;
