import React, { Component } from "react";
import { Link } from 'react-router';

class Landing extends Component{
	render(){
		return(
			<center>
				<div class="jumbotron">
				  <h3>Welcome to React Redux</h3>
				  <p>
				       <button className="btn btn-default" ><Link to='/register' >Register</Link></button>
				         &nbsp; <button className="btn btn-default"><Link to='/login' >Login</Link></button>

				  </p>
				</div>
				</center>
			);
	}
}
export default Landing;