
import { combineReducers } from "redux"

import auth from './authreducer'

export default combineReducers({ 
  auth
})