export default function reducer(state={"isAuth":false},action){
    
    switch(action.type){
           
        case "LOGIN_USER":
        
        console.log("loged in",action.payload)
        var msg
        if(action.payload.success){    
         state={...state,data:action.payload.data,isAuth:true}   
        }
        else{         
            state={...state,data:[],msg:'Login Failed'}
        }
        break; 

        default:
        break;
    }
    return state
}

