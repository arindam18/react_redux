 import {Route,browserHistory} from 'react-router';
export function loginUser(userdata){
    console.log("Calling function !!!-LoginUser")
    return function(dispatch){
	    console.log("LoginUser",userdata);
	    userdata = {...userdata,success:true};
	    dispatch({type:"LOGIN_USER",payload:userdata})
	    alert("loged in");   
    
    }
}