import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import App from './components/App';
import Login from './components/auth/login';
import store from './store';
import registerServiceWorker from './registerServiceWorker';
import './styles/index.css';

import {Router, Route, browserHistory, IndexRoute} from 'react-router';

ReactDOM.render( 
	<Provider store={store}>
		<Router history={browserHistory}>
			<Route path="/" component={App} ></Route>
			<Route path="/login" component={Login}></Route> 
		</Router>
	</Provider>, document.getElementById('root'));
registerServiceWorker();